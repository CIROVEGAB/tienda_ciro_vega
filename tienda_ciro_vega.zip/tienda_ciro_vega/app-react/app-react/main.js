import React from 'react'
import ReactDOM from 'react-dom'
import { render } from 'react-dom'
import { BrowserRouter as Router, Route } from 'react-router-dom'; 
//import App from './App.jsx'
import Formulario from './formulario.jsx'
import Bodega from './bodega.jsx'

render(<Formulario />, document.getElementById('app'));
